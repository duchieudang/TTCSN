package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.SinhVien;
import model.Diem;
import model.DiemDanh;
import model.Lop;


public class SinhVienDAO implements DAOInterface<SinhVien> {

	  @Override
	    public ArrayList<SinhVien> selectAll() {
	        ArrayList<SinhVien> ketQua = new ArrayList<>();
	        try {
	            Connection con = JDBCUtil.getConnection();
	            String sql = "SELECT * FROM sinhvien";
	            PreparedStatement st = con.prepareStatement(sql);
	            ResultSet rs = st.executeQuery();
	            while (rs.next()) {
	                String maSinhVien = rs.getString("masinhvien");
	                String tenSinhVien = rs.getString("tensinhvien");
	                Date ngaySinh = rs.getDate("ngaysinh");
	                String gioiTinh = rs.getString("gioitinh");
	                String diaChi = rs.getString("diachi");
	                String soDienThoai = rs.getString("sodienthoai");
	                String email = rs.getString("email");
	                String matKhau = rs.getString("matkhau");  // Lấy mật khẩu
	                String maLop = rs.getString("malop");
	                Lop lop = new Lop(maLop, "", "", "", null);
	                SinhVien sinhVien = new SinhVien(maSinhVien, tenSinhVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, matKhau, lop);
	                ketQua.add(sinhVien);
	            }
	            JDBCUtil.closeConnection(con);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return ketQua;
	    }

	  @Override
	    public SinhVien selectById(SinhVien t) {
	        SinhVien ketQua = null;
	        try {
	            Connection con = JDBCUtil.getConnection();
	            String sql = "SELECT * FROM sinhvien WHERE masinhvien=?";
	            PreparedStatement st = con.prepareStatement(sql);
	            st.setString(1, t.getMaSinhVien());
	            ResultSet rs = st.executeQuery();
	            if (rs.next()) {
	                String maSinhVien = rs.getString("masinhvien");
	                String tenSinhVien = rs.getString("tensinhvien");
	                Date ngaySinh = rs.getDate("ngaysinh");
	                String gioiTinh = rs.getString("gioitinh");
	                String diaChi = rs.getString("diachi");
	                String soDienThoai = rs.getString("sodienthoai");
	                String email = rs.getString("email");
	                String matKhau = rs.getString("matkhau");  // Lấy mật khẩu
	                String maLop = rs.getString("malop");

	                Lop lop = new Lop(maLop, "", "", "", null);
	                ketQua = new SinhVien(maSinhVien, tenSinhVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, matKhau, lop);
	            }
	            JDBCUtil.closeConnection(con);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return ketQua;
	    }
	  @Override
	    public int insert(SinhVien t) {
	        int ketQua = 0;
	        try {
	            Connection con = JDBCUtil.getConnection();
	            String sql = "INSERT INTO sinhvien (masinhvien, tensinhvien, ngaysinh, gioitinh, diachi, sodienthoai, email, matkhau, malop) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
	            PreparedStatement st = con.prepareStatement(sql);
	            st.setString(1, t.getMaSinhVien());
	            st.setString(2, t.getTenSinhVien());
	            st.setDate(3, new java.sql.Date(t.getNgaySinh().getTime()));
	            st.setString(4, t.getGioiTinh());
	            st.setString(5, t.getDiaChi());
	            st.setString(6, t.getSoDienThoai());
	            st.setString(7, t.getEmail());
	            st.setString(8, t.getMatKhau());  // Thêm mật khẩu
	            st.setString(9, t.getLop().getMaLop());
	            ketQua = st.executeUpdate();
	            JDBCUtil.closeConnection(con);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return ketQua;
	    }

	  @Override
	    public int update(SinhVien t) {
	        int ketQua = 0;
	        try {
	            Connection con = JDBCUtil.getConnection();
	            String sql = "UPDATE sinhvien SET tensinhvien=?, ngaysinh=?, gioitinh=?, diachi=?, sodienthoai=?, email=?, matkhau=?, malop=? WHERE masinhvien=?";
	            PreparedStatement st = con.prepareStatement(sql);
	            st.setString(1, t.getTenSinhVien());
	            st.setDate(2, new java.sql.Date(t.getNgaySinh().getTime()));
	            st.setString(3, t.getGioiTinh());
	            st.setString(4, t.getDiaChi());
	            st.setString(5, t.getSoDienThoai());
	            st.setString(6, t.getEmail());
	            st.setString(7, t.getMatKhau());  // Cập nhật mật khẩu
	            st.setString(8, t.getLop().getMaLop());
	            st.setString(9, t.getMaSinhVien());
	            ketQua = st.executeUpdate();
	            JDBCUtil.closeConnection(con);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return ketQua;
	    }

	public ArrayList<SinhVien> selectByMaLop(String maLop) {
	    ArrayList<SinhVien> listSinhVien = new ArrayList<>();
	    Connection con = null;

	    try {
	        con = JDBCUtil.getConnection();
	        String sql = "SELECT * FROM SinhVien WHERE malop = ?";
	        PreparedStatement st = con.prepareStatement(sql);
	        st.setString(1, maLop);
	        ResultSet rs = st.executeQuery();

	        while (rs.next()) {
	            // Lấy thông tin từ ResultSet
	            String maSinhVien = rs.getString("masinhvien");
	            String tenSinhVien = rs.getString("tensinhvien");
	            Date ngaySinh = rs.getDate("ngaysinh");
	            String gioiTinh = rs.getString("gioitinh");
	            String diaChi = rs.getString("diachi");
	            String soDienThoai = rs.getString("sodienthoai");
	            String email = rs.getString("email");
	            String matKhau = rs.getString("matkhau"); 
	        
	           
	            Lop lop = new Lop(maLop, "", "", "", null); // Nếu cần thêm thông tin về lớp
	            
	            // Khởi tạo đối tượng SinhVien và thiết lập các thuộc tính
	            SinhVien sinhVien = new SinhVien(maSinhVien, tenSinhVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, matKhau, lop);
	            
	            // Thêm sinh viên vào danh sách
	            listSinhVien.add(sinhVien);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        JDBCUtil.closeConnection(con);
	    }
	    
	    return listSinhVien;
	}

	public SinhVien selectByUsernameAndPassWord(SinhVien t) {
	    SinhVien ketQua = null;
	    Connection con = null;
	    try {
	        con = JDBCUtil.getConnection();
	        String sql = "SELECT * FROM sinhvien WHERE masinhvien=? AND matkhau=?";
	        PreparedStatement st = con.prepareStatement(sql);
	        st.setString(1, t.getMaSinhVien());
	        st.setString(2, t.getMatKhau());

	        ResultSet rs = st.executeQuery();

	        if (rs.next()) {
	            String maSinhVien = rs.getString("masinhvien");
	            String tenSinhVien = rs.getString("tensinhvien");
	            Date ngaySinh = rs.getDate("ngaysinh");
	            String gioiTinh = rs.getString("gioitinh");
	            String diaChi = rs.getString("diachi");
	            String soDienThoai = rs.getString("sodienthoai");
	            String email = rs.getString("email");
	          
	            String matKhau = rs.getString("matkhau");
	            String maLop = rs.getString("malop");
	            Lop lop = new Lop(maLop, "", "", "", null);
	            ketQua = new SinhVien(maSinhVien, tenSinhVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, matKhau, lop);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        JDBCUtil.closeConnection(con);
	    }
	    return ketQua;
	}
	public SinhVien selectByMaSinhVien(String maSinhVien) {
	    SinhVien ketQua = null;
	    try {
	        Connection con = JDBCUtil.getConnection();
	        String sql = "SELECT * FROM sinhvien WHERE masinhvien=?";
	        PreparedStatement st = con.prepareStatement(sql);
	        st.setString(1, maSinhVien);

	        System.out.println(sql);
	        ResultSet rs = st.executeQuery();

	        if (rs.next()) {
	            String matKhau = rs.getString("matkhau");
	            String tenSinhVien = rs.getString("tensinhvien");
	            String gioiTinh = rs.getString("gioitinh");
	            String diaChi = rs.getString("diachi");
	            Date ngaySinh = rs.getDate("ngaysinh");
	            String soDienThoai = rs.getString("sodienthoai");
	            String email = rs.getString("email");
	       
	            String maLop = rs.getString("malop");
	            Lop lop = new Lop(maLop, "", "", "", null);
	            ketQua = new SinhVien(maSinhVien, tenSinhVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, matKhau, lop);
	        }

	        JDBCUtil.closeConnection(con);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return ketQua;
	}

	@Override
	public int delete(SinhVien t) {
	    int ketQua = 0;
	    try {
	        Connection con = JDBCUtil.getConnection();

	        // Step 1: Delete associated `diem` records
	        DiemDAO diemDAO = new DiemDAO();
	        ArrayList<Diem> listDiem = diemDAO.selectByMaSinhVien(t.getMaSinhVien());
	        for (Diem diem : listDiem) {
	            ketQua += diemDAO.delete(diem);
	        }

	        // Step 2: Delete associated `diemdanh` records
	        DiemDanhDAO diemDanhDAO = new DiemDanhDAO();
	        ArrayList<DiemDanh> listDiemDanh = diemDanhDAO.selectByMaSinhVien(t.getMaSinhVien());
	        for (DiemDanh diemDanh : listDiemDanh) {
	            ketQua += diemDanhDAO.delete(diemDanh);
	        }

	        // Step 3: Delete the `sinhvien` record
	        String sql = "DELETE FROM sinhvien WHERE masinhvien=?";
	        PreparedStatement st = con.prepareStatement(sql);
	        st.setString(1, t.getMaSinhVien());
	        ketQua += st.executeUpdate();

	        JDBCUtil.closeConnection(con);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return ketQua;
	}


	// Hàm kiểm tra mã sinh viên đã tồn tại trong cơ sở dữ liệu chưa
	public int sosanh(String maSinhVienMoi) {
		int dem = 0;
		try {
			Connection con = JDBCUtil.getConnection();
			String sql = "SELECT COUNT(*) FROM sinhvien WHERE masinhvien = ?";
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, maSinhVienMoi);
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				dem = rs.getInt(1); // Lấy số lượng bản ghi trùng mã sinh viên
			}
			JDBCUtil.closeConnection(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dem;
	}

	

	@Override
	public int insertAll(ArrayList<SinhVien> arr) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteAll(ArrayList<SinhVien> arr) {
		// TODO Auto-generated method stub
		return 0;
	}
}
