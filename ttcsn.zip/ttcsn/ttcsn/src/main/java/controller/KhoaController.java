package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import model.Khoa;
import database.KhoaDAO;

@WebServlet("/khoa")
@MultipartConfig(fileSizeThreshold = 1024 * 1024, maxFileSize = 10 * 1024 * 1024, maxRequestSize = 50 * 1024 * 1024)
public class KhoaController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        KhoaDAO khoaDAO = new KhoaDAO();
        ArrayList<Khoa> listKhoa = khoaDAO.selectAll();
        request.setAttribute("listKhoa", listKhoa);

        String action = request.getParameter("action");
        if ("add".equals(action)) {
            request.setAttribute("showAddModal", true);
        }

        request.getRequestDispatcher("Khoa.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        KhoaDAO khoaDAO = new KhoaDAO();

        switch (action) {
            case "add":
                String maKhoa = request.getParameter("maKhoa");
                String tenKhoa = request.getParameter("tenKhoa");
                int dem = khoaDAO.sosanh(maKhoa);

                if (dem > 0) {
                    request.setAttribute("status", "success4");
                    request.setAttribute("message", "Đã trùng mã khoa. Yêu cầu nhập lại!");
                    request.getRequestDispatcher("Khoa.jsp").forward(request, response);
                } else {
                    Khoa khoa = new Khoa(maKhoa, tenKhoa);
                    khoaDAO.insert(khoa);
                    response.sendRedirect("khoa?status=success");
                }
                return;

            case "delete":
                String maKhoaToDelete = request.getParameter("maKhoa");
                Khoa khoaToDelete = new Khoa();
                khoaToDelete.setMaKhoa(maKhoaToDelete);
                khoaDAO.delete(khoaToDelete);
                response.sendRedirect("khoa?status=success2");
                return;

            case "update":
                String maKhoaToUpdate = request.getParameter("maKhoa");
                String newTenKhoa = request.getParameter("tenKhoa");
                Khoa khoaToUpdate = new Khoa(maKhoaToUpdate, newTenKhoa);
                khoaDAO.update(khoaToUpdate);
                response.sendRedirect("khoa?status=success3");
                return;
          
            

            default:
                response.sendRedirect("khoa?status=error&message=Invalid action");
                return;
        }
    }
}
