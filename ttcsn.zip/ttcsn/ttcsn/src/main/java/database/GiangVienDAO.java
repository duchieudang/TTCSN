package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import model.GiangVien;

public class GiangVienDAO implements DAOInterface<GiangVien> {

    @Override
    public ArrayList<GiangVien> selectAll() {
        ArrayList<GiangVien> ketQua = new ArrayList<>();
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM giangvien";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maGiangVien = rs.getString("magiangvien");
                String tenGiangVien = rs.getString("tengiangvien");
                Date ngaySinh = rs.getDate("ngaysinh");
                String gioiTinh = rs.getString("gioitinh");
                String diaChi = rs.getString("diachi");
                String soDienThoai = rs.getString("sodienthoai");
                String email = rs.getString("email");
                String chuyenNganh = rs.getString("chuyennganh");
                String matKhau = rs.getString("matkhau");

                GiangVien giangVien = new GiangVien(maGiangVien, tenGiangVien, ngaySinh, gioiTinh, diaChi, soDienThoai,
                        email, chuyenNganh, matKhau);
                ketQua.add(giangVien);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return ketQua;
    }
    public GiangVien selectByEmail(String email) {
        GiangVien giangVien = null;
        String query = "SELECT * FROM giangvien WHERE email = ?"; // Thay giangvien bằng tên bảng giảng viên trong CSDL của bạn
        Connection connection = null;

        try {
            connection = JDBCUtil.getConnection(); // Mở kết nối từ JDBCUtil
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);

            ResultSet resultSet = preparedStatement.executeQuery();

            // Kiểm tra xem có giảng viên nào có email trùng khớp không
            if (resultSet.next()) {
                String maGiangVien = resultSet.getString("maGiangVien");
                String tenGiangVien = resultSet.getString("tenGiangVien");
                Date ngaySinh = resultSet.getDate("ngaySinh");
                String gioiTinh = resultSet.getString("gioiTinh");
                String diaChi = resultSet.getString("diaChi");
                String soDienThoai = resultSet.getString("soDienThoai");
                String chuyenNganh = resultSet.getString("chuyenNganh");
                String matKhau = resultSet.getString("matKhau");

                giangVien = new GiangVien(maGiangVien, tenGiangVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, chuyenNganh, matKhau);
            }

            // Đóng các đối tượng PreparedStatement và ResultSet
            preparedStatement.close();
            resultSet.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(connection); // Đóng kết nối từ JDBCUtil
        }

        return giangVien;
    }
    @Override
    public GiangVien selectById(GiangVien t) {
        GiangVien ketQua = null;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM giangvien WHERE magiangvien=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaGiangVien());
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maGiangVien = rs.getString("magiangvien");
                String tenGiangVien = rs.getString("tengiangvien");
                Date ngaySinh = rs.getDate("ngaysinh");
                String gioiTinh = rs.getString("gioitinh");
                String diaChi = rs.getString("diachi");
                String soDienThoai = rs.getString("sodienthoai");
                String email = rs.getString("email");
                String chuyenNganh = rs.getString("chuyennganh");
                String matKhau = rs.getString("matkhau");

                ketQua = new GiangVien(maGiangVien, tenGiangVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email,
                        chuyenNganh, matKhau);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return ketQua;
    }
    public GiangVien selectByMaGiangVien(String maGiangVien) {
        GiangVien ketQua = null;
        try {
            Connection con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM giangvien WHERE magiangvien=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maGiangVien);

            System.out.println(sql);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                String matKhau = rs.getString("matkhau");
                String tenGiangVien = rs.getString("tengiangvien");
                String gioiTinh = rs.getString("gioitinh");
                String diaChi = rs.getString("diachi");
                Date ngaySinh = rs.getDate("ngaysinh");
                String soDienThoai = rs.getString("sodienthoai");
                String email = rs.getString("email");
                String chuyenNganh = rs.getString("chuyennganh");

                ketQua = new GiangVien(maGiangVien, tenGiangVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, chuyenNganh, matKhau);
            }

            JDBCUtil.closeConnection(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ketQua;
    }

    public GiangVien selectByUsernameAndPassWord(GiangVien t) {
        GiangVien ketQua = null;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM giangvien WHERE magiangvien=? AND matkhau=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaGiangVien());
            st.setString(2, t.getMatKhau());

            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                String maGiangVien = rs.getString("magiangvien");
                String tenGiangVien = rs.getString("tengiangvien");
                Date ngaySinh = rs.getDate("ngaysinh");
                String gioiTinh = rs.getString("gioitinh");
                String diaChi = rs.getString("diachi");
                String soDienThoai = rs.getString("sodienthoai");
                String email = rs.getString("email");
                String chuyenNganh = rs.getString("chuyennganh");
                String matKhau = rs.getString("matkhau");

                ketQua = new GiangVien(maGiangVien, tenGiangVien, ngaySinh, gioiTinh, diaChi, soDienThoai, email, chuyenNganh, matKhau);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return ketQua;
    }

    public int sosanh(String maGiangVienMoi) {
        int dem = 0;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "SELECT COUNT(*) FROM giangvien WHERE magiangvien = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maGiangVienMoi);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                dem = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return dem;
    }

    @Override
    public int insert(GiangVien t) {
        int ketQua = 0;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "INSERT INTO giangvien (magiangvien, tengiangvien, ngaysinh, gioitinh, diachi, sodienthoai, email, chuyennganh, matkhau) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaGiangVien());
            st.setString(2, t.getTenGiangVien());
            st.setDate(3, new java.sql.Date(t.getNgaySinh().getTime()));
            st.setString(4, t.getGioiTinh());
            st.setString(5, t.getDiaChi());
            st.setString(6, t.getSoDienThoai());
            st.setString(7, t.getEmail());
            st.setString(8, t.getChuyenNganh());
            st.setString(9, t.getMatKhau());
            ketQua = st.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return ketQua;
    }

    @Override
    public int update(GiangVien t) {
        int ketQua = 0;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "UPDATE giangvien SET tengiangvien=?, ngaysinh=?, gioitinh=?, diachi=?, sodienthoai=?, email=?, chuyennganh=?, matkhau=? WHERE magiangvien=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getTenGiangVien());
            st.setDate(2, new java.sql.Date(t.getNgaySinh().getTime()));
            st.setString(3, t.getGioiTinh());
            st.setString(4, t.getDiaChi());
            st.setString(5, t.getSoDienThoai());
            st.setString(6, t.getEmail());
            st.setString(7, t.getChuyenNganh());
            st.setString(8, t.getMatKhau());
            st.setString(9, t.getMaGiangVien());
            ketQua = st.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return ketQua;
    }

    @Override
    public int delete(GiangVien t) {
        int ketQua = 0;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "DELETE FROM giangvien WHERE magiangvien=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, t.getMaGiangVien());
            ketQua = st.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return ketQua;
    }

    @Override
    public int insertAll(ArrayList<GiangVien> arr) {
        int dem = 0;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "INSERT INTO giangvien (magiangvien, tengiangvien, ngaysinh, gioitinh, diachi, sodienthoai, email, chuyennganh, matkhau) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);

            for (GiangVien giangVien : arr) {
                st.setString(1, giangVien.getMaGiangVien());
                st.setString(2, giangVien.getTenGiangVien());
                st.setDate(3, new java.sql.Date(giangVien.getNgaySinh().getTime()));
                st.setString(4, giangVien.getGioiTinh());
                st.setString(5, giangVien.getDiaChi());
                st.setString(6, giangVien.getSoDienThoai());
                st.setString(7, giangVien.getEmail());
                st.setString(8, giangVien.getChuyenNganh());
                st.setString(9, giangVien.getMatKhau());
                dem += st.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return dem;
    }

    public GiangVien getGiangVienByMaGiangVien(String maGiangVien) {
        GiangVien giangVien = null;
        Connection con = null;
        try {
            con = JDBCUtil.getConnection();
            String sql = "SELECT * FROM giangvien WHERE magiangvien = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, maGiangVien);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String maGiangVienResult = rs.getString("magiangvien");
                String tenGiangVien = rs.getString("tengiangvien");
                Date ngaySinh = rs.getDate("ngaysinh");
                String gioiTinh = rs.getString("gioitinh");
                String diaChi = rs.getString("diachi");
                String soDienThoai = rs.getString("sodienthoai");
                String email = rs.getString("email");
                String chuyenNganh = rs.getString("chuyennganh");
                String matKhau = rs.getString("matkhau");

                giangVien = new GiangVien(maGiangVienResult, tenGiangVien, ngaySinh, gioiTinh, diaChi, soDienThoai,
                        email, chuyenNganh, matKhau);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.closeConnection(con);
        }
        return giangVien;
    }

	@Override
	public int deleteAll(ArrayList<GiangVien> arr) {
		// TODO Auto-generated method stub
		return 0;
	}
	 public static void main(String[] args) {
	        GiangVienDAO giangVienDAO = new GiangVienDAO();

	        // 1. Thêm mới một giảng viên
	        GiangVien newGiangVien = new GiangVien("GV001", "Nguyen Van A", 
	                Date.valueOf("1985-01-01"), "Nam", "123 ABC Street", 
	                "0123456789", "nva@example.com", "CNTT", "password123");
	        int insertResult = giangVienDAO.insert(newGiangVien);
	        if (insertResult > 0) {
	            System.out.println("Thêm giảng viên mới thành công!");
	        } else {
	            System.out.println("Thêm giảng viên thất bại!");
	        }

	        // 2. Lấy tất cả giảng viên
	        System.out.println("\nDanh sách tất cả giảng viên:");
	        ArrayList<GiangVien> giangViens = giangVienDAO.selectAll();
	        for (GiangVien gv : giangViens) {
	            System.out.println(gv);
	        }

	        // 3. Cập nhật thông tin giảng viên
	        GiangVien updateGiangVien = new GiangVien("GV001", "Nguyen Van A Updated", 
	                Date.valueOf("1985-01-01"), "Nam", "456 DEF Street", 
	                "0987654321", "nva_updated@example.com", "CNTT", "newpassword123");
	        int updateResult = giangVienDAO.update(updateGiangVien);
	        if (updateResult > 0) {
	            System.out.println("\nCập nhật thông tin giảng viên thành công!");
	        } else {
	            System.out.println("\nCập nhật thông tin giảng viên thất bại!");
	        }

	        // 4. Lấy giảng viên theo mã giảng viên
	        GiangVien fetchedGiangVien = giangVienDAO.selectByMaGiangVien("GV001");
	        if (fetchedGiangVien != null) {
	            System.out.println("\nThông tin giảng viên có mã GV001:");
	            System.out.println(fetchedGiangVien);
	        } else {
	            System.out.println("\nKhông tìm thấy giảng viên có mã GV001!");
	        }

	        // 5. Xóa giảng viên
	    
	        // 6. Kiểm tra mã giảng viên đã tồn tại
	        int checkResult = giangVienDAO.sosanh("GV001");
	        if (checkResult > 0) {
	            System.out.println("\nMã giảng viên GV001 đã tồn tại!");
	        } else {
	            System.out.println("\nMã giảng viên GV001 chưa tồn tại!");
	        }
	    }
}
